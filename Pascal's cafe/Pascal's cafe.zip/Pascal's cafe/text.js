let navbar = document.querySelector('#navbar');

document.querySelector('menu-btn').onclick ()=>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
}
let searchForm = document.querySelector('.search-form');

document.querySelector('search-btn').onclick ()=>{
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
}
let cartItem = document.querySelector('.cart-items-container');

document.querySelector('cart-btn').onclick ()=>{
    cartItem.classList.toggle('active');
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
}
window.onscroll=()=>{
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
}
Headers. onscroll=()=>{
    navbar.classList.remove('hide');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
}
const searchBtn = document.querySelector('.search-btn');
const searchForm = document.querySelector('.search-form');

searchBtn.addEventListener('click', function() {
  searchForm.classList.toggle('active');
});
